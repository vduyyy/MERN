import React from 'react';
import './App.css';
import Pokelist from './components/Pokelist';
import axios from 'axios';
import {Router} from '@reach/router';
import Pageone from './components/Pageone';
import Pagetwo from './components/Pagetwo';
import Pagethree from './components/Pagethree'; 


function App() {

  return (
     
    <div className="App">
        <Router>
          <Pageone path="/home"/>
          <Pagetwo path="/:id"/>
          <Pagethree path ="/:name/:color1/:color2"/>
        </Router>
    </div>
  );
}

export default App;
