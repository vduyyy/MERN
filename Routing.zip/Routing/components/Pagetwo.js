import React from 'react'; 
import {Link} from '@reach/router'; 

const Pagetwo = props =>{
    return (
        <div> 
            <h1>{props.id}</h1>
            
            <Link to= "/home">Welcome back </Link>
        </div>
    )
}

export default Pagetwo; 