import React, {useState} from 'react'; 
import {Link} from '@reach/router'; 


const Pagethree = (props) =>{
    const [state, setState] = useState({
        lstyle: {
            color : props.color2, 
            background:props.color1, 
            width: "300px"
        }
    })
    return (
    isNaN(props.color1) && isNaN(props.color2) ? 
        <div style = {state.lstyle}> 
            <h1>{props.name}</h1> 
            <Link  to='/home'> Welcome Back</Link>
        </div> : <div style={{...state.lstyle, color: "black", background: "white"}}> <h1>{props.name}</h1></div>
    );
}

export default Pagethree; 