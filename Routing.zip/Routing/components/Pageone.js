import React from 'react'; 
import {Link, navigate} from '@reach/router'; 

const Pageone = props =>{
    const onClickHandler = e =>{
        e.preventDefault();
        navigate('/:id')
    }
    return (
        <div> 
            <h1>Welcome</h1>
            <Link to= "/:id">Go to {props.id}</Link>
            <button onClick ={onClickHandler}> Click Me</button>
        </div>
    )
}

export default Pageone; 