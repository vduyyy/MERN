import React from 'react';
import './App.css';
import Form from './components/Form';
import {Router} from "@reach/router";
import ShowAll from './components/ShowAll';


function App() {
  return (
    <div className="App">
      <Router >
      <Form path ="newPlayer"/>
      <ShowAll path ="AllPlayer"/>
      </Router>
    </div>
  );
}

export default App;
