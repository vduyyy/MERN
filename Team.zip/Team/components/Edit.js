import React from "react"; 

const Edit = (props) =>{
    const [formState, setFormState] = useState({
        name: "", 
        position: "",
        game: ""
    })

    useEffect(() =>{
        axios.get(`http://localhost:8000/api/team/updatePlayer/${props.id}`)
        .then(response =>{
            setFormState({...response.data})
        })
        .catch(error => console.log(error))
    }, [props.id])

const onChangeHandler = (e) =>{
    setFormState({
        ...formState, 
        [e.target.name]: e.target.value
    })
}

const [errorState, setErrorState] = useState({
    name: "",
    position: "",
    game: ""
})

const onSubmitHandler = (e) =>{
    e.preventDefault();
    axios.put(`http://localhost:8000/api/team/updatePlayer/${formState._id}`, formState)
    .then(response =>{
        console.log(response)
        if(response.data.errors){
            setErrorState({
                name: response.data.errors.name ?
                response.data.errors.name.message : "",
                position: response.data.errors.position ? 
                response.data.errors.position.message : "",
                game: response.data.erros.game ? 
                response.data.errors.game.message : ""
            })
        } 
    })
    .catch (error => console.log(error))
}

return ( 
    <div> 
        <strong> {errorState.name}</strong> <br/>
        <strong> {errorState.position}</strong> <br/>
        <strong> {errorState.game}</strong>

        <form onSubmite = {onSubmitHandler}>
            <lable> Player Name: </lable>
            <input type ="text" name = "name" value ={formState.name} onChang= {onChangeHandler}/>
            <lable> Player Position: </lable>
            
        </form>
    </div>
)
}