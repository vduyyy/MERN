import React, {useState, useEffect} from 'react';
import axios from 'axios'; 
import {Link } from '@reach/router'; 

const ShowAll = prop=>{
    const[state, setState] = useState([])
    const [deleteState, setDeleteState] = useState([])
    useEffect(() =>{
        axios.get('http://localhost:8000/api/team/Allplayers')
        .then(response => setState(response.data))
        .catch(error =>console.log(error))
    },[deleteState])



const onDeleteHandler = (e, item) =>{
    axios.delete(`http://localhost:8000/api/team/deleteplayer/${item._id}`)
    .then (response =>{
        setDeleteState(!deleteState)
        alert("Are you sure? ${item.name}")
    })
    .catch(error => console.log(error))

}

    return (
        <div> 
            <Link to ="/newPlayer" style ={{margin: '5px'}}>Add Player</Link> |
            <Link to ="/newPlayer" style ={{margin: '5px'}}>Manage Player Status</Link> |
            <Link to ="/newPlayer" style ={{margin: '5px'}}>Manage Players</Link>
            <table style = {{marginLeft: "550px", marginTop: '10px'}}> 
                <thead>
                    <tr>
                        <th>Player Name:</th>
                        <th>Player Position:</th>
                        <th>Action:</th>
                    </tr>
                </thead>
                <tbody>
                    {state.map((item, idx) =>(
                        <tr key ={idx}>
                            <td>{item.name} </td>
                            <td>{item.position}</td>
                            <td>
                                <button onClick ={(e) => onDeleteHandler(e,item)}>Destory</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}

export default ShowAll; 
