import React, {useState} from "react";
import {navigate} from "@reach/router"; 
import axios from 'axios'; 
import 'bootstrap/dist/css/bootstrap.min.css';


const Form = props =>{
    const [formState, setFormState] = useState({
        name: "",
        position: "", 
    })

const [errorState, setErrorState] = useState({
    name: "", 
    position: "",

})


const onChangeHandler = (e) =>{
    setFormState({
        ...formState, 
            [e.target.name]: e.target.value,
            [e.target.position]: e.target.value

    })
}

const onSubmitHandler = (e) =>{
    e.preventDefault(); 
    axios.post("http://localhost:8000/api/team/newPlayer", formState)
        .then(response =>{
            if (response.data.errors) {
                setErrorState({
                    name: response.data.errors.name ? 
                    response.data.errors.name.message : "", 
                    position: response.data.errors.position ? 
                    response.data.errors.position.message : ""
                })
            } else {
                navigate("/AllPlayer")
            }
        })
        .catch(error => console.log(error))

}


return (
    <div> 
        <strong>{errorState.name}</strong><br/>
        <strong>{errorState.position}</strong>
        <form onSubmit= {onSubmitHandler}>
            <p>
                <label>Player Name:</label>
                <input type="text" name="name" onChange = {onChangeHandler}/>
            </p>
            <select name ="position" onChange={onChangeHandler}>
                <option value = "Forward">Forward</option>
                <option value = "Mid Field">Mid Field</option>
                <option value = "Goalkeeper">Goalkeeper</option>
                
            </select>
            <p></p>
            <button type ="submit"> ADD</button>
        </form>
    </div>
)
}

export default Form; 