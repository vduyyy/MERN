import React, {useState} from 'react'; 



    const RegisterForm = props => {
        const [ formState, setFormState] = useState({
            firstName: "",
            lastName: "",
            email: "",
            password:"",
            confirmPassword: ""
        })
        const onChangeHandler = event => {
            setFormState({
                ...formState,
                [event.target.name]: event.target.value
            });
        }
        const onSumbitHandler = event => {
            event.preventDefault();
            console.log(formState);
            console.log(formState.email);
        }
    
    return (
        <div> 
           
            <form onSubmit={onSumbitHandler}>
                <label>First Name</label>
                <input type="text" name="firstName" onChange={onChangeHandler}/>
                <br/>        
                <label>Last Name</label>
                <input type="text" name="lastName" onChange={onChangeHandler}/>
                <br/>        
                <label>Email</label>
                <input type="email" name="email" onChange={onChangeHandler}/>
                <br/>        
                <label>Password</label>
                <input type="password" name="password" onChange={onChangeHandler}/>
                <br/>        
                <label>Confirm Password</label>
                <input type="password" name="confirmPassword" onChange={onChangeHandler}/>
                <br/>   
                <input type="submit" />
            </form>

            <h3> Form Data:</h3>
            <p>{formState.firstName}</p>
            <p>{formState.lastName}</p>
            <p>{formState.email}</p>
            <p>{formState.password}</p>
            <p>{formState.confirmPassword}</p>
        


        </div>
    );
}




export default RegisterForm; 
