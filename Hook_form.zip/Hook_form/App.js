import React from 'react';
import './App.css';
import Newcomponent from './components/Newcomponent';
import RegisterForm from './components/Wrapper';

function App() {

  return (
    <div className="App">
      <RegisterForm/>
    </div>
  );
}

export default App;
