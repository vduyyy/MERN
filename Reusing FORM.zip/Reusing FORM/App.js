import React from 'react';
import Form from "./components/Form"; 
import './App.css';
import ProductsList from "./components/ProductsList";
import Detail from "./components/Detail";
import {Router} from '@reach/router';
import Edit from "./components/Edit"; 
import Home from "./components/Home"
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
       <Home />
      <Router>
      <Form path = "/dashboard"/>
      <ProductsList path= "/allproducts"/>
      <Detail path = "/products/findOne/:id"/>
      <Edit path = "/products/updateOne/:id"/>
     </Router>
    </div>
  );
}

export default App;
