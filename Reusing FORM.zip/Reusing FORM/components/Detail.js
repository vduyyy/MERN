import React, {useEffect, useState} from 'react'; 
import axios from 'axios'; 

const Detail = (props) =>{
    const [state, setState] = useState({})
    useEffect(()=>{
        axios.get(`http://localhost:8000/api/products/findOne/${props.id}`)
        .then(response => {
            console.log(response)
            setState({...response.data})
        })
        .catch(error => console.log(error))
}, [props.id])

return (
    <div> 
        <h2> Title: {state.title}</h2>
        <h2> Price: {state.price}</h2>
        <h2> Description: {state.description}</h2>
    </div>
)
}

export default Detail; 