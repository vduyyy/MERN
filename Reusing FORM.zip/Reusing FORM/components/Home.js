import React from 'react'; 
import {Link} from "@reach/router"; 

const Home = (props) =>{
    return (
        <div> 
            <h1> Welcome to Home Page </h1>
            <Link style = {{margin: '5px'}} to ="/dashboard"> New </Link> |
            <Link style = {{margin: '5px'}} to ="/homepage"> Home</Link> |
            <Link style = {{margin: '5px'}} to ="/allproducts"> All</Link> |
        </div>
    )
}

export default Home; 