import React, {useState, useEffect} from 'react'; 
import axios from 'axios'; 
import {navigate} from "@reach/router"; 


const Edit = (props) =>{
    const [formState, setFormState] = useState({
        title: "", 
        price: "", 
        description: ""
    })
    useEffect(() =>{
        axios.get(`http://localhost:8000/api/products/findOne/${props.id}`)
        .then(response =>{
            setFormState({ ...response.data})
        })
        .catch(error => console.log(error))
    }, [props.id])

    const onChangeHandler = (e) => {
        setFormState({
            ...formState,
            [e.target.name]: e.target.value
        })
    }
    const [errorState, setErrorState] = useState({
        title: "",
        description: ""
    })


    const onSubmitHandler= (e) =>{
        e.preventDefault();
        axios.put(`http://localhost:8000/api/products/updateOne/${formState._id}`, formState)
        .then (response =>{
            console.log(response)
            if(response.data.errors){
                setErrorState({
                    title: response.data.errors.title ? response.data.errors.title.message : "",
                    description:response.data.errors.description  ? 
                    response.data.errors.description.message : ""
                })
 
            } else {
                console.log("You Updated")

                navigate("/allproducts")
            }
        })
        .catch(error => console.log(error))
    }
    return (
        <div> 
                <p>{errorState.title}</p>
                <p>{errorState.description}</p>
            <form onSubmit={onSubmitHandler}>
                <p>
                    <label> Title</label>
                    <input type="text" name="title" onChange={onChangeHandler}  value = {formState.title}/>
                </p>
                <p>
                    <label> Price</label>
                    <input type="text" name="price" onChange={onChangeHandler} value ={formState.price} />
                </p>
                <p>
                    <label> Description</label>
                    <input type="text" name="description" onChange={onChangeHandler} value= {formState.description} />
                </p>
                <button type="submit">Edit Products</button>
            </form>
        </div>
    )
}

export default Edit; 