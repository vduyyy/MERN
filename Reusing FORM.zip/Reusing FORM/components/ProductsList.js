import React, { useState, useEffect } from 'react'; 
import axios from 'axios'; 
import {navigate, Link} from '@reach/router';

const ProductList = props =>{
    const [state,setState] = useState([])
    const [deleteState, setDeleteState] = useState([])
    useEffect(()=>{
        axios.get('http://localhost:8000/api/products/all')
            .then(response => setState(response.data))
            .catch(error=>console.log(error))
    },[deleteState ])

  
    const onDeleteHandler = (e, item) =>{
        console.log(item._id)
        axios.delete(`http://localhost:8000/api/products/deleteOne/${item._id}`)
            .then (response => {
                console.log(response)
                setDeleteState(!deleteState)
            })
            .catch(error => console.log(error))
    }

    const Edit = (e, item)=>{
     navigate(`products/updateOne/${item._id}`); 
 }
    return (
        <div> 
            <table> 
                <thead>
                    <tr> 
                        <th> Title:</th>
                        <th> Price:</th>
                        <th> Action:</th>
                    </tr>
                </thead>
            <tbody>
            {state.map((item, idx) =>(
                <tr key={idx}> 
                    <td><Link to={`/products/findOne/${item._id}`}>{item.title}</Link></td>
                    <td> {item.price}</td>
                    <td> 
                        <button  onClick ={(e) => Edit(e, item)}>Edit</button> | <button onClick ={(e) => onDeleteHandler(e, item)}> Destory</button>
                    </td>
                </tr>
            ))}
            </tbody>
            </table>
        </div>
    )
}

export default ProductList