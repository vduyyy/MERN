import React from 'react';
import './App.css';
import Pokelist from './components/Pokelist';
import axios from 'axios';
import {Router} from '@reach/router';
import Pageone from './components/Pageone';
import Pagetwo from './components/Pagetwo';
import Pagethree from './components/Pagethree'; 


function App() {

  return (
     
    <div className="App">
      <Pageone path ="/home"/>
        <Router>
          <Pagetwo path="/people/:id"/>
          <Pagethree path ="/planet/:id"/>
        </Router>
    </div>
  );
}

export default App;
