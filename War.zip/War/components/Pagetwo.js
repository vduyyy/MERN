import React, {useContext, useState, useEffect} from 'react'; 
import {Link} from '@reach/router'; 
import Axios from 'axios';

const Pagetwo = props =>{
    const[formState, setFormState] = useState({})
    useEffect(() =>{
    Axios.get(`https://swapi.co/api/people/${props.id}`)
    .then(response=> setFormState(response.data))
        }, [props.uri]); 

    return ( // can i use id instead?
        <div>
          <h1>{formState.name}</h1>
          <p> Height:{formState.height};</p>
          <p>Hair Color:{formState.hair_color}</p>
          <p>Eye Color :{formState.eye_color}</p>
          <p>skin Color:{formState.skin_color}</p>
        
        </div>
         )
          
}

export default Pagetwo; 