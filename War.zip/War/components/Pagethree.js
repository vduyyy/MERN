import React, {useState, useEffect} from 'react'; 
import {Link} from '@reach/router'; 
import axios from 'axios'; 

const Pagethree = (props) =>{
    const [formState, setFormState] = useState({})
    useEffect(() => {
        axios.get(`https://swapi.co/api/planets/${props.id}`) 
            .then(response => setFormState(response.data))
    }, [props.id]);
    return (
        <div>
            <h1>{formState.name}</h1>
            <p>climate: {formState.climate}</p>
            <p>Terrain {formState.terrain}</p>
            <p>Surfacr Water {formState.surface_water}</p>
            <p>Population {formState.population}</p>
        </div>
    )
}

export default Pagethree; 