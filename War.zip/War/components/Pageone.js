import React, {useState} from 'react'; 
import {Link, navigate} from '@reach/router'; 
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import {Dropdown, Button} from 'react-bootstrap';


const Pageone = () =>{
    const[fromState, setFormState] = useState(
        {
            people: []
        }
    );
const [state, setState] = useState({
    id:"1", 
    name: "people"

})
const onClickHandler = (e) =>{
    e.preventDefault()
    navigate(`/${state.name}/${state.id}`)
}

const checkBox = (e) =>{
    e.preventDefault();
    setState({
        ...state, [e.target.name]: e.target.value
    })
}

    return (
      <div>
          <form>
            <select name ="name" onChange={checkBox}>
                <option value="people">People</option>
                <option value="planet">Planet</option>
            </select>
            <label>
                <input onChange ={checkBox} name ="id"/>
            </label>
            <Button onClick ={onClickHandler}> Search</Button>
          </form>
      </div>
    );
}


export default Pageone; 