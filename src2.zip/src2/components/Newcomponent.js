import React, {Component} from 'react'; 

class Newcomponent extends Component{
    constructor(props){
        super(props);
        this.state = {
            age: this.props.age
        }
    }
    handleClick = () => {
        this.setState({
            age: this.state.age+1
        })
    }
    render(){
        return(
        <div>
            <h1> {this.props.name} </h1>
            <p> {this.props.age} </p>
            <p> {this.props.hair} </p>
            <button onClick= {this.handleClick}>Your {this.state.age}</button>
         </div>
        );
    }
}

export default Newcomponent; 