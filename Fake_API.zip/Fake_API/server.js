const express =require("express");
const app = express(); 
const faker = require("faker");

let count = 0;
class Person{
    constructor(){
        this.firstName = faker.name.firstName(); 
        this.lastName = faker.name.lastName(); 
        this.phoneNumber = faker.phone.phoneNumber(); 
        this.email = faker.internet.email(); 
        this.password = faker.internet.password(); 
        this.id = count;
        count++
    }
}

let CC = 0; 
class Company{
    constructor(){
        this.name = faker.company.companyName(); 
        this.street = faker.address.streetAddress();
        this.city = faker.address.city();
        this.zipCode = faker.address.zipCode();
        this.country = faker.address.country();
        this.id = CC; 
        CC++
    }
}


app.get("/api", (req,res) => {
    return res.json({newUser: new Person()}); 
    res.send("Our express api server is now sending this over to the browser What is wrong");
});

app.use(express.json());
app.use(express.urlencoded({extended: true}));
app.post("/api/users/new", (req, res) =>{
    console.log(req.body);

    const newUser = req.body;
    return res.status(201).json({newUser: newUser});
});


app.post("/api/companies/new", (req, res)=> {
    console.log(req.body); 

    const newCompany = req.body; 
    return res.status(201).json({newCompany: newCompany});
});

app.get("/api/user/companies", (req, res) =>{
    console.log(req.body); 
    return res.json({newUser: new Person(), newCompany: new Company}); 

})


// Get User with a ID from a URL 
// whatever you typed after the colon in the url, it will become the "KEY" in the req.params object
// app.get("/api/users/:whatIwant", (req, res)=>{
//     // can also deconstruct the param object: 

//     const { whatIwant} = req.params; 

// });




//whenever we want to UPDATE the DATA: 

// app.put("/api/users/update/:id", (req, res) =>{
//     // we will update the user using the ID from the param and the data from req.body

// }); 

// //DESTORY a USER 

// app.delete("/api/users/delete/:id", (req, res)=>{
//     console.log(req.params.id)
// })

const server = app.listen(8005, ()=>
console.log(`Server is Locked and loaded on port ${server.address().port}!`)
);