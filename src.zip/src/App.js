import React from 'react';
import './App.css';
import Newcomponent from './components/Newcomponent';

function App() {
  return (
    <div className="App">
      <Newcomponent name = {"Doe, John"} age = {"Age: 45"} hair = {"Hair: Black"}/>
      <Newcomponent name = {"Smith, Sara"} age = {"Age: 100"} hair = {"Hair: blone"}/>
      <Newcomponent name = {"Doe, Pete"} age = {"Age: 26"} hair = {"Hair: Green"}/>
      


      
    </div>
  );
}

export default App;
