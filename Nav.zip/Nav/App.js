import React from 'react';
import Inputwrapper from './components/Inputwrapper';
import Nav from './components/Nav';
import Wrapper from './components/Wrapper';
import './App.css';


function App(){
  return (
    <div className="App">
    <Wrapper>
      <Nav/>
      <Inputwrapper/>
    </Wrapper>
    </div>
  );
}

export default App;
