import React, {useState} from 'react'; 

const Task = props => {
    const [state, setState] = useState({
        Task:[]
    })

    const [formState, setFormState] = useState({
        name: "",
        checked: false

    })
    const [checked, setChecked] = React.useState(true);
    
    const onSubmitHandler= (e) =>{
        e.preventDefault();
        setState({Task:[...state.Task, formState] })
        setFormState({
            name: "",
            checked: false
        })
    }
    const onCheck = (e) => {
        setFormState({
            ...formState,
            [e.target.name]: e.target.value
        });
    }

    const deleteHandler = (e, index) => {
        e.preventDefault();
        setState({ Task: state.Task.filter((el, i) => i != index) })
    };
2
    const onChangeHandler = (e, i) => {
        console.log(e.target.checked)
        const temp = [...state.Task]
        temp[i].checked = e.target.checked;
        setState({ Task: temp })
    };


        return (
            <div>
            <form onSubmit = {onSubmitHandler}>
                <label>
                    <p>Name:</p>
                    <input  type ="text" onChange ={onCheck} name ="name" value={formState.name} placeholder="Enter Task"/>
                </label>
                <input type="submit" value ="ADD"/>
            </form>
            {
                state.Task.map((item, i)=>(
                    item.checked ===false ?
                    <div key ={i}>
                        {item.name}
                            <button onClick={(e) => deleteHandler(e,i)}>Delete</button>
                            <input type="checkbox" onChange={(e) => onChangeHandler(e, i)} />
                            </div>
                            : <div key={i}>
                                <p>{item.name}</p>
                            </div>
                ))
            }
          </div> 
            
        );
    }

export default Task; 