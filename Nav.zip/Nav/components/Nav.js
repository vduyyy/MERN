import React, {useContext} from 'react'; 
import MyContext from './MyContext';

const Nav =() => {
    const context = useContext(MyContext)
    return (
        <div> 
            
            Welcome + {context.state.inputName}
                   
        </div>
    );
}

export default Nav; 