import React, {useState} from 'react'
import MyContext from './MyContext';

const Wrapper =(props) => {
    const [state,setState] = useState({
        inputName: ""
    })

    return (
        <div>
            <MyContext.Provider value ={{state, setState}}>
            {props.children}
            </MyContext.Provider>
        </div>
    )
}

export default Wrapper; 