import React, {useState} from 'react';
import Form from './Form';

const InputWrapper = () => {
    return (
        <div> 
            <Form/>
        </div>
    )
}

export default InputWrapper; 

