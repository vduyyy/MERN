import React, {useContext} from 'react';
import MyContext from './MyContext';

const Form = () =>{

    
const context = useContext(MyContext)
const checkbox =(e) => {
    context.setState({ inputName: e.target.value});
}

return (
    <lable>
        <p>Name:</p>
        <input onChange={(e) => checkbox(e)}
            name ="inputName" value ={context.state.inputName} />
    </lable>
     
    );
}

export default Form; 