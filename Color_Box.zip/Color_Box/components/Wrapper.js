import React, {useState} from 'react'; 

    const RegisterForm = props => {
    const [ formState, setFormState] = useState({
            firstName: "",
            lastName: "",
            email: "",
            password:"",
            confirmPassword: "",
            submitted: false
        })
        const onChangeHandler = event => {
            setFormState({
                ...formState,
                [event.target.name]: event.target.value
            });
        }
        const onSumbitHandler = event => {
            event.preventDefault();
            console.log(formState);
            setFormState({
                ...formState, submitted: true
            })
        }
    
    return (
        <div> 
           {formState.submitted && <h1> You have submitted a form </h1>}
           
            <form onSubmit={onSumbitHandler}>

                <label>First Name</label>
                <input type="text" name="firstName" onChange={onChangeHandler}/>
                {formState.firstName > 0 && formState.firstName < 3 &&  <p> First Name must be more then 3 letter</p>}
                <br/>
                
                <label>Last Name</label>
                <input type="text" name="lastName" onChange={onChangeHandler}/>
                { formState.lastName >0 &&formState.lastName < 3 && <p> Last Name must be more then 3 letter</p>}
                <br/>        
                <label>Email</label>
                <input type="email" name="email" onChange={onChangeHandler}/>
                
                <br/>        
                <label>Password</label>
                <input type="password" name="password" onChange={onChangeHandler}/>
                { formState.password >0 && formState.password < 5  && <p> It must have more then 5 letters</p>}
                <br/>        
                <label>Confirm Password</label>
                <input type="password" name="confirmPassword" onChange={onChangeHandler}/>
                { formState.confirmPassword == formState.password && <p> It must match</p>}
                <br/>   
                <input type="submit"/>
            </form>

            <h3> Form Data:</h3>
            <p> First Name: {formState.firstName}</p>
            <p> Last Name: {formState.lastName}</p>
            <p> Email: {formState.email}</p>
            <p> Password: {formState.password}</p>
            <p> confirmPassword{formState.confirmPassword}</p>
        </div>
    );
}



export default RegisterForm; 
