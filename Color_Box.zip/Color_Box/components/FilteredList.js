import React, {useState} from 'react';


const Box = props => {
    const [state, setState] = useState({
        listbox: []
    })

    const [formState, setFormState] = useState({
        color: "",
        width: "", 
        height: ""
    })

    const onChangeHandler = (event) => {
        setFormState({
            ...formState,
            [event.target.name]: event.target.value
        });
    }

    const onSubmitHandler = (e) => {
        e.preventDefault();
        setState({listbox:[...state.listbox,{color:formState.color,width:formState.width+ "px", height:formState.height+"px"}]})
        setFormState({
            color:"",
            width:"",
            height: ""
        })
    }

    return (
        <div>
        <form onSubmit ={onSubmitHandler}> 
        <div> 
            <label>
                <p>Color:</p>
                <input onChange = {onChangeHandler} name="color" value ={formState.color}/>
            </label>
            <label>
                <p>Height:</p>
                <input onChange = {onChangeHandler} name="height" value ={formState.height}/>
            </label>
            <label>
                <p>Width:</p>
                <input onChange = {onChangeHandler} name="width" value ={formState.width}/>
            </label>
            <input type ="submit" value ="ADD"/>
        </div>
        </form>
        {
            state.listbox.map((item,i) =>(
                <div key ={i} style ={{backgroundColor: item.color, width: item.width, height: item.height}}/>
            ))
        }
        </div>
        
    );
}


export default Box;