import React from 'react';
import './App.css';
import Newcomponent from './components/Newcomponent';
import Box from './components/FilteredList';
function App() {

  return (
    <div className="App">
      <Box/>
    </div>
  )
}

export default App;
