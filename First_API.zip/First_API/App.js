import React from 'react';
import './App.css';
import Pokelist from './components/Pokelist';
import axios from 'axios';

function App() {

  return (
     
    <div className="App">
        <Pokelist/>
    </div>
  );
}

export default App;
