import React, {useState} from 'react'

const Pokelist =() => {
    const [state, setState] = useState(
    {list: [] }
    );
    const onClick=(e) => {
    (fetch("https://pokeapi.co/api/v2/pokemon")
    .then(res =>{
        return res.json(); 
    }) 
    .then(res =>setState({list: res.results}))
    .catch(err =>{
        console.log(err);
    }))
}
    return (
        <div>
            <div>
            <button type ="submit" onClick ={onClick}>Catch Them All</button>
            </div> 
            <div> {
            state.list.map((item, i) =>(
                <p key={i}> {item.name}</p>
                ))
                }
            </div>
        </div>
    );
}



export default Pokelist; 