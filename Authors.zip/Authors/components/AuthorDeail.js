import React, {useEffect, useState} from 'react'; 
import axios from 'axios'; 

const AuthorDeail = (props) =>{
    const [state, setState] = useState({})
    useEffect(() =>{
        axios.get(`http://localhost:8000/api/Authors/findOne/${props.id}`)
        
        .then(response => {
            console.log(response)
            setState({...response.data})
    })
    .catch(error => console.log(error))
}, [props.id])


    return(
        <div> 
            <h1> Authors Detail</h1>
            <h2> Name: {state.name}</h2>
        </div>
    )
}

export default AuthorDeail; 