import React from 'react'; 
import {Link} from '@reach/router'; 

const Home = (props) =>{
    return (
        <div> 
            <h1> Welcome to Home Page</h1>
            <Link  style = {{margin: "5px"}} to ="/CreateAuthor">Make An Author</Link> |
            <Link style = {{margin: "5px"}} to ="/ShowAll">Show All Authors</Link> | 
            <Link style = {{margin: "5px"}} to ="/homepage">Home</Link> 


        </div>
    )
}

export default Home; 