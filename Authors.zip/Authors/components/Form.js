import React, {useState} from 'react'; 
import {navigate} from '@reach/router'; 
import axios from 'axios'; 
import {Button} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

const Form = props =>{
    const[formState, setFormState] = useState({
        name: ""
    })

    const [errorState, setErrorState] = useState({
        name: ""
    })

    const onChangeHandler = (e) =>{
        setFormState({
            ...formState, 
            [e.target.name]: e.target.value
        })
    }

    const onClickHandler = (e) =>{
        e.preventDefault();
        navigate("/ShowAll")
    }

    const onSubmitHandler = (e) =>{
        e.preventDefault(); 
        axios.post("http://localhost:8000/api/Authors/new", formState)
            .then(response =>{
                if(response.data.errors){
                    setErrorState({
                        name: response.data.errors.name ?
                        response.data.errors.name.message : ""
                    })
                } else {
                    navigate("/ShowAll")
                }
            })
            .catch (error => console.log(error))
    }

    return (
        <div> 
                <p>Create A New Author</p>
                <strong>{errorState.name}</strong>

            <form onSubmit = {onSubmitHandler}>
                <p>
                    <label> Author Name: </label>
                    <input type = "text" name ="name" onChange = {onChangeHandler}/>
                </p>
                <Button  style = {{margin: "5px"}} type= "submit"> Create</Button> 
                <Button onClick = {onClickHandler}> Cancel</Button>
            </form>
        </div>
    )
}

export default Form; 