import React, {useState, useEffect} from 'react'; 
import axios from 'axios'; 
import {navigate} from '@reach/router';
import {Button} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';


const Edit = (props) =>{
    const [formState, setFormState] = useState({
        name: ""
    })

    useEffect(()=> {
        axios.get(`http://localhost:8000/api/Authors/findOne/${props.id}`)
        .then(response =>{
            setFormState({...response.data})
        })
        .catch (error =>  console.log(error))
    }, [props.id])

    const onSubmitHandler =(e) =>{
        e.preventDefault(); 
        axios.put(`http://localhost:8000/api/Authors/updateOne/${formState._id}`, formState)
        .then(response =>{
            if(response.data.errors){
                setErrorState({
                    name: response.data.errors.name ?
                    response.data.errors.name.message : ""
                })
            } else {
                console.log("You update")
                navigate("/ShowAll")
            }
        })
        .catch (error => console.log(error))
}

    const onChangeHandler = (e) => {
        setFormState({
            ...formState,
            [e.target.name]: e.target.value
        })
    }
    const [errorState, setErrorState] = useState({
        name: "",
    })

    const onClickHandler = (e) =>{
        e.preventDefault();
        navigate("/ShowAll")
    }

    return(
        <div> 
            <strong>Edit this Author</strong>
            <p>{errorState.name}</p>
            <form onSubmit = {onSubmitHandler}>
                <p>
                    <label> Author Name: </label>
                    <input type = "text" name ="name" onChange = {onChangeHandler} value = {formState.name}/>
                </p>
                <Button style = {{margin: "5px"}} type= "submit"> Edit</Button>
                <Button  onClick = {onClickHandler}> Cancel</Button>

            </form>
        </div>
    )
}

export default Edit; 