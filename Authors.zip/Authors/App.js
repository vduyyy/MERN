import React from 'react';
import Home from './components/Home';
import './App.css';
import Form from './components/Form';
import {Router} from '@reach/router';
import All from './components/All'; 
import AuthorDeail from './components/AuthorDeail'; 
import Edit from './components/Edit';

function App() {
  return (
    <div className="App">

    <Home path ="homepage"/>
    <Router>
    <Form path= "/CreateAuthor"/>
    <All path = "/ShowAll"/>
    <AuthorDeail path = "/findOne/:id"/>
    <Edit path ="editOne/:id"/>
    </Router>
    </div>
  );
}

export default App;
