const mongoose = require('mongoose'); 
const Product = mongoose.model("Product"); 

module.exports = {
    create : (req, res) =>{
        Product.create(req.body)
            .then(response => res.json(response))
            .catch(err => res.json(err))
    },
    findAll : (req, res) =>{
        Product.find({})
        .then(response => res.json(response))
        .catch(err => res.json(err))
    }, 
    findOne : (req, res) =>{
        Product.findOne({_id: request.params.id})
        .then(product => response.json(product))
        .catch(err => response.json(err))
    }
}