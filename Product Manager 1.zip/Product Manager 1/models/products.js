const mongoose = require("mongoose"); 

const ProductSchema = new mongoose.Schema({
    title: {
        type: String, 
        minlength:[3, "It must be 3 longer"]
    }, 
    price: {
        type:Number, 
    },
    description: {
        type: String, 
        minlength: [5, "It must be 5 charcter or longer"]
    },
}, {timestamps: true})


mongoose.model("Product", ProductSchema); 