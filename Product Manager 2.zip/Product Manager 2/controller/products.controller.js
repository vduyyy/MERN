const mongoose = require('mongoose'); 
const Product = mongoose.model("Product"); 

module.exports = {
    create : (req, res) =>{
        Product.create(req.body)
            .then(response => res.json(response))
            .catch(err => res.json(err))
    },
    findAll : (req, res) =>{
        Product.find({})
        .then(response => res.json(response))
        .catch(err => res.json(err))
    }, 
    findOne : (req, res) =>{
        Product.findOne({_id: req.params.id})
        .then(response => res.json(response))
        .catch(err => res.json(err))
    },
    deleteOne : (req, res) =>{
        Product.deleteOne({_id: req.params.id})
        .then(response => res.json(response))
        .catch(err => res.json(err))
    },
}