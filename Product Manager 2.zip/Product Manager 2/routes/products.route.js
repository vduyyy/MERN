const ProductController = require("../controller/products.controller");

module.exports = app =>{
    app.post("/api/products/new", ProductController.create); 
    app.get("/api/products", ProductController.findAll);
    app.get("/api/products/readOne/:id", ProductController.findOne);
    app.delete("/api/products/deleteOne/:id", ProductController.deleteOne);
};
