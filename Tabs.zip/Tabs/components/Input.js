import React, {useState} from 'react';
const Tabs = props =>{
   const [state, setState] = useState({
    listbox: [{ label: "Table 1", content: "This is T1"},
              { label: "Table 2", content: "This is T2"},
              { label: "Table 3", content: "This is T3"},
        ],
   })
       
   const onClickHandler = (e, index) => {
       e.preventDefault();
       setState({
           ...state, 
            val: index, 
       })
    }
    return (
        <div>
        {
            state.listbox.map((item, index) => (
                index == state.val ? <div key={index} onClick ={(e) => onClickHandler(e, index)}>{item.label}</div> : <div key={index} onClick = {(e) => onClickHandler(e, index)}> {item.label}</div>
        ))
      }
      {state.listbox.map((item,index) => (
          index == state.val ? <div> {item.content}</div> : null 
      ))}
      </div>

    );
    }
export default Tabs;