import React, { useState } from 'react'; 

const Newcomponent = props => {
   const[state, setState] = useState({
       age: props.age 
   })
   const clickHandler = e => {
       console.log(state)
       setState({
           age: state.age+1
           
       })
   }
    return(
    <div>
        <h1>{props.name} </h1>
        <p> {state.age} </p>
       <button onClick={clickHandler}> Increase Your Age: </button>
        <p> {props.hair} </p>
     </div>
    );
}




export default Newcomponent; 