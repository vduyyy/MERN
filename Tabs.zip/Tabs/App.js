import React from 'react';
import './App.css';
import Newcomponent from './components/Newcomponent';
import Box from './components/FilteredList';
import Tabs from './components/Input';
function App() {

  return (
    <div className="App">
      <Tabs/>
    </div>
  )
}

export default App;
