import React from 'react';
import './App.css';
import Pokelist from './components/Pokelist';
import axios from 'axios';

function App() {



    // useEffect(() =>{
    //   axios.get("https://pokeapi.co/api/v2/pokemon")
    //   .then(res =>{
    //     setPokemon(res.data.results.map(i => i.name))

    //   })
    // }, []) 

  return (
     
    <div className="App">
        <Pokelist/>
    </div>
  );
}

export default App;
