import React, {useState, useEffect} from 'react'
import axios from 'axios'; 

const Pokelist =() => {
    const [state, setState] = useState(
    {list: [] }
    );
    const onClick=(e) => {
    axios.get("https://pokeapi.co/api/v2/pokemon")

    .then(res =>setState({list: res.data.results}))
    .catch(err =>{
        console.log(err);
    })
    
}
    return (
        <div>
            <div>
            <button type ="submit" onClick ={onClick}>Catch Them All</button>
            </div> 
            <div> {
            state.list.map((item, i) =>(
                <p key={i}> {item.name}</p>
                ))
                }
            </div>
        </div>
    );
}



export default Pokelist; 