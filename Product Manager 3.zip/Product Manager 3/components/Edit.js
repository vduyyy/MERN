import React, {useState} from 'react'; 
import axios from 'axios'; 
import {navigate} from "@reach/router"; 


const Edit = (props) =>{
    const [formState, setFormState] = useState({
        title: "", 
        price: "", 
        description: ""
    })

    const onChangeHandler = (e) => {
        setFormState({
            ...formState,
            [e.target.name]: e.target.value
        })
    }
    const [errorState, setErrorState] = useState({
        title: "",
        description: ""
    })


    const onSubmitHandler= (e) =>{
        axios.put(`http://localhost:8000/api/products/editOne/${formState._id}`, formState)
        .then (response =>{
            console.log.apply(response)
            if(response.data.errors){
                setErrorState({
                    title: response.data.errors.title ?
                    response.data.errors.titl.message : "",
                    description: response.data.errors.description ? response.data.errors.description.message:""
                })
            } else {
                console.log("You Updated")
                navigate("/allproducts")
            }
        })
        .catch(error => console.log(error))
    }
    return (
        <div> 
            <form onSubmit={onSubmitHandler}>
                <p>{errorState.title}</p>
                <p>{errorState.description}</p>
                <p>
                    <label> Title</label>
                    <input type="text" name="title" onChange={onChangeHandler}  value = {formState.title}/>
                </p>
                <p>
                    <label> Price</label>
                    <input type="text" name="price" onChange={onChangeHandler} value ={formState.price} />
                </p>
                <p>
                    <label> Description</label>
                    <input type="text" name="description" onChange={onChangeHandler} value= {formState.description} />
                </p>
                <button type="submit">Edit Products</button>
            </form>
        </div>
    )
}

export default Edit; 