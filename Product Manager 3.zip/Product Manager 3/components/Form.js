import React, { useState } from 'react';
import axios from 'axios';

const Form = props => {
    const [formState, setFormState] = useState({
        title: "",
        price: "",
        description: ""
    })

    const [errorState, setErrorState] = useState({
        title: "",
        description: ""
    })

    const onChangeHandler = (e) => {
        setFormState({
            ...formState,
            [e.target.name]: e.target.value
        })
    }

    const onSubmitHandler = (e) => {
        e.preventDefault();
        axios.post("http://localhost:8000/api/products/new", formState)
            .then(response => {
                if (response.data.errors) {
                    setErrorState({
                        title: response.data.errors.title.message,
                        description: response.data.errors.description.message
                    })
                }
            })
            .catch(error => console.log(error))
    }

    return (
        <div>
            <form onSubmit={onSubmitHandler}>
                <p>{errorState.title}</p>
                <p>{errorState.description}</p>
                <p>
                    <label> Title</label>
                    <input type="text" name="title" onChange={onChangeHandler} />
                </p>
                <p>
                    <label> Price</label>
                    <input type="text" name="price" onChange={onChangeHandler} />
                </p>
                <p>
                    <label> Description</label>
                    <input type="text" name="description" onChange={onChangeHandler} />
                </p>
                <button type="submit">Create</button>
            </form>
        </div>
    )


}

export default Form; 