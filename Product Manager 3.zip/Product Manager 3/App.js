import React from 'react';
import Form from "./components/Form"; 
import './App.css';
import ProductsList from "./components/ProductsList";
import Detail from "./components/Detail";
import {Router} from '@reach/router';
import Edit from "./components/Edit"; 

function App() {
  return (
    <div className="App">
      <Router>
     <Form path = "/dashboard"/>
     <ProductsList path = "/allproducts"/>
     <Detail path = "/products/readOne/:id"/>
     <Edit path = "/products/EditOne/:id"/>
     </Router>
    </div>
  );
}

export default App;
